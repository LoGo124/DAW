public interface Comparable {
    public int compareTo(Cotxe p);
}
