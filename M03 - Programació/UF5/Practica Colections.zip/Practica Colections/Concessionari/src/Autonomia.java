public interface Autonomia {

    public int getAutonomia();
}
